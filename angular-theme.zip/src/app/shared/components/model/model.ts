export interface Menu {
    icon: string,
    label: string
}
